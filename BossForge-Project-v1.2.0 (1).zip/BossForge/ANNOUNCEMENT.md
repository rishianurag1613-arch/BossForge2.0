# 📢 BOSSFORGE UPDATE — SURVIVAL RECIPES + CUSTOM TEXTURES!

BossForge has been updated to **v1.2.0**!

✨ **What's new?**

- Seven boss eggs can now be crafted using ordinary vanilla survival items.
- All custom core items have been removed — no admin-only recipe ingredients.
- The Boss Forge recipe now matches the updated recipe guide.
- Each egg recipe can still be crafted only once globally. Once the first player crafts it, that recipe locks for the entire server.
- Seven custom egg textures and a Boss Forge inventory icon are included in a separate Minecraft Java 1.21.11 resource pack.
- Each egg starts a peaceful guardian supply challenge.
- Boss spawn coordinates are announced in chat, with a progress bar for the event.
- The top supply contributor earns the matching commemorative relic.

## Boss Forge recipe

```text
Obsidian   Diamond       Obsidian
Iron Ingot Crafting Table Iron Ingot
Obsidian   Diamond       Obsidian
```

## Boss Egg recipes

All recipes use one normal chicken egg. Craft them in the Boss Forge's 3×3 GUI. Put the exact totals anywhere in the 3×3 input slots—ingredient positions do not matter.

**Wooden Egg** — 4 Oak Logs + 4 Oak Planks + 1 Egg

```text
Oak Log    Oak Planks  Oak Log
Oak Planks Egg         Oak Planks
Oak Log    Oak Planks  Oak Log
```

**Stone Egg** — 8 Cobblestone + 1 Egg

```text
Cobblestone Cobblestone Cobblestone
Cobblestone Egg         Cobblestone
Cobblestone Cobblestone Cobblestone
```

**Copper Egg** — 4 Copper Ingots + 4 Copper Blocks + 1 Egg

```text
Copper Ingot Copper Block Copper Ingot
Copper Ingot Egg          Copper Block
Copper Ingot Copper Block Copper Block
```

**Iron Egg** — 8 Iron Ingots + 1 Egg

**Golden Egg** — 8 Gold Ingots + 1 Egg

**Diamond Egg** — 8 Diamonds + 1 Egg

**Netherite Egg** — 8 Netherite Ingots + 1 Egg

## Important rules

- Every recipe is a one-time global craft. The first successful craft locks that egg recipe for the whole server.
- All ingredients are ordinary vanilla items obtainable in Survival.
- Exact totals matter; slot order does not. Extra or incorrect items will be rejected.
- No custom cores or custom tokens are needed.
- Install the included `BossForge-Resource-Pack-1.21.11.zip` to see the custom egg and Boss Forge item textures.

Have fun crafting and completing all seven peaceful guardian challenges!
